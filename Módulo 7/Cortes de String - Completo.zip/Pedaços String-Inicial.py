#!/usr/bin/env python
# coding: utf-8

# ### Forma Básica

# In[ ]:


precos = "Jan: 25, Fev: 27, Mar: 29"


# ### Posição Inicial e Final

# In[ ]:





# ### Posição Inicial e Final com Step

# In[ ]:


codigo = "1.2.3.4,5,1,2.3.4,7.9"


# In[ ]:




